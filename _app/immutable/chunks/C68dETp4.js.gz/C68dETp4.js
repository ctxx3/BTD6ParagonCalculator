var s;const t=((s=globalThis.__sveltekit_a81wd)==null?void 0:s.base)??"/BTD6ParagonCalculator";var a;const e=((a=globalThis.__sveltekit_a81wd)==null?void 0:a.assets)??t;export{e as a,t as b};
