import{l as o,a as r}from"../chunks/7YaDO7xK.js";export{o as load_css,r as start};
